CarePrecise (R) Authoritative Hospital Database(TM)
Data structure and contents copyright 2008, 2009, 2010, 2011, 2012, 2013, 
2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023 by CarePrecise llc. All Rights Reserved.

CarePreciseLLC
httpS://www.careprecise.com

Description of data fields is found in the included DataDescription_AHD.pdf document.

License: Purchaser of this data package has purchased not the data or data structure but a limited license to use same within their own organization only. The data may not be sold or otherwise disseminated in any way, including but not limited to inclusion in a derivative product, website, published document, software application, or database. Redistribution licensing is available for an additional charge; for information contact CarePrecise Sales at 1-877-782-2294 extension 2.
